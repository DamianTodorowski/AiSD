namespace c_s_5
{
    public partial class Form1 : Form
    {
        string napis = "";
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Wezel w1 = new Wezel(5);
            //Wezel w2 = new Wezel(3);
            //Wezel w3 = new Wezel(1);
            //Wezel w4 = new Wezel(2);
            //Wezel w5 = new Wezel(4);
            //Wezel w6 = new Wezel(6);
            //w1.dzieci.Add(w2);
            //w1.dzieci.Add(w3);
            //w1.dzieci.Add(w4);
            //w2.dzieci.Add(w5);
            //w2.dzieci.Add(w6);
            //A(w1);
            //void A(Wezel w)
            //{
            //    napis += " " + w.wartosc.ToString();
            //    for (int i = 0; i < w.dzieci.Count; i++)
            //    {
            //        A(w.dzieci[i]);
            //    }
            //}


            //MessageBox.Show(napis);

            //................................................Wywo�anie pracy domowej..........................
            DrzewoBinarne drzewo = new DrzewoBinarne(5);
            drzewo.Add(4);
            drzewo.Add(2);
            drzewo.Add(3);
            drzewo.Add(8);
            drzewo.Add(7);
            drzewo.Add(6);
            drzewo.Add(9);
            //znajdz
            Wezel3 szukanyWezel = drzewo.Znajdz(9);
            if (szukanyWezel != null)
            {
                MessageBox.Show("Znaleziono w�ze� o warto�ci: " + szukanyWezel.wartosc);
            }
            else
            {
               MessageBox.Show("Nie znaleziono w�z�a o podanej warto�ci.");
            }
            //warto�c min.
            int minValue = drzewo.ZnajdzMin(drzewo.korzen);
            
            MessageBox.Show("Najmniejsza warto�� w drzewie: " + minValue);
            //Warto�� max
            int MaxValue = drzewo.ZnajdzMax(drzewo.korzen);
            MessageBox.Show("Najwieksza warto�� w drzewie:"+ MaxValue);
            //nastepnik
            Wezel3 wezelDoSprawdzenia = drzewo.Znajdz(3);
            int nastepnikValue = drzewo.Nastepnik(wezelDoSprawdzenia);
            MessageBox.Show("Nast�pnik w�z�a o warto�ci " + wezelDoSprawdzenia.wartosc + " to: " + nastepnikValue);
            //poprzednik
            
            int poprzednikValue = drzewo.Poprzednik(wezelDoSprawdzenia);
            MessageBox.Show("Poprzednik w�z�a o warto�ci " + wezelDoSprawdzenia.wartosc + " to: " + poprzednikValue);
        }



        List<Wezel2> wezel2s;
        private void button2_Click(object sender, EventArgs e)
        {
            wezel2s = new List<Wezel2>();

            Wezel2 w1 = new Wezel2(1);
            Wezel2 w2 = new Wezel2(2);
            Wezel2 w3 = new Wezel2(3);
            Wezel2 w4 = new Wezel2(4);
            Wezel2 w5 = new Wezel2(5);
            Wezel2 w6 = new Wezel2(6);
            Wezel2 w7 = new Wezel2(7);
            w1.Add(w2);
            w1.Add(w7);
            w2.Add(w3);
            w3.Add(w4);
            w4.Add(w5);
            w5.Add(w6);
            w6.Add(w7);
            B(w4);
            MessageBox.Show(napis);
        }
        void B(Wezel2 w)
        {
            wezel2s.Add(w);
            napis += " " + w.wartosc.ToString();
            foreach (var sasiad in w.sasiednie)
            {
                if (!wezel2s.Contains(sasiad))
                {
                    wezel2s.Add(sasiad);
                    B(sasiad);
                }

            }
        }
    }

    public class Wezel
    {
        public int wartosc;
        public List<Wezel> dzieci = new List<Wezel>();

        public Wezel(int liczba)
        {
            this.wartosc = liczba;
        }
    }
    public class Wezel2
    {
        public int wartosc;
        public List<Wezel2> sasiednie = new List<Wezel2>();

        public Wezel2(int wartosc)
        {
            this.wartosc = wartosc;
        }
        public void Add(Wezel2 w)
        {
            if (this == w) return;
            if (this.sasiednie.Contains(w)) return;
            this.sasiednie.Add(w);
            w.sasiednie.Add(this);
        }
    }
    public class Wezel3
    {
        public int wartosc;
        public Wezel3 rodzic;
        public Wezel3 leweDziecko;
        public Wezel3 praweDziecko;

        public Wezel3(int liczba)
        {
            this.wartosc = liczba;
        }

        internal void Add(int number)
        {
            var dziecko = new Wezel3(number);
            dziecko.rodzic = this;
            if (number < this.wartosc)
                this.leweDziecko = dziecko;
            else
                this.praweDziecko = dziecko;
        }
        
    }

    public class DrzewoBinarne
    {
        public Wezel3 korzen;

        public DrzewoBinarne(int liczba)
        {
            this.korzen = new Wezel3(liczba);
        }

        public void Add(int number)
        {
            Wezel3 rodzic = this.ZnjadzRodzica(number);
            rodzic.Add(number);
        }
        private Wezel3 ZnjadzRodzica(int number)
        {
            var w = this.korzen;
            while (true)
            {
                if (number < w.wartosc)
                {
                    if (w.leweDziecko == null)
                    {
                        return w;
                    }
                    else
                        w = w.leweDziecko;
                }
                else
                {
                    if (w.praweDziecko == null)
                    {
                        return w;
                    }
                    else
                        w = w.praweDziecko;
                }
            }
        }
        //....................................PRACA DOMOWA....................................................
        public Wezel3 Znajdz(int liczba)
        {
            return ZnajdzRekurencyjnie(korzen, liczba);
        }
        private Wezel3 ZnajdzRekurencyjnie(Wezel3 w, int liczba)//w= this.korzen pamietaj
        {
            if (w.wartosc == liczba)
            {
                return w;
            }
            else if (w == null)
            {
                return null;
            }

            if (liczba < w.wartosc)
            {
                return ZnajdzRekurencyjnie(w.leweDziecko, liczba);
            }
            else
            {
                return ZnajdzRekurencyjnie(w.praweDziecko, liczba);
            }
        }
        public int ZnajdzMin(Wezel3 startowyWezel)
        {
            if (startowyWezel == null)
            {
                throw new ArgumentNullException(nameof(startowyWezel),"Podany wezel nie mo�e by� nullem"); 
            }

            Wezel3 aktualnyWezel = startowyWezel;

            while (aktualnyWezel.leweDziecko != null)
            {
                aktualnyWezel = aktualnyWezel.leweDziecko;
            }

            return aktualnyWezel.wartosc;
        }

        public int ZnajdzMax(Wezel3 startowyWezel)
        {
            if (startowyWezel == null)
            {
                throw new ArgumentNullException(nameof(startowyWezel), "Podany w�ze� nie mo�e by� null.");
            }

            Wezel3 aktualnyWezel = startowyWezel;

            while (aktualnyWezel.praweDziecko != null)
            {
                aktualnyWezel = aktualnyWezel.praweDziecko;
            }

            return aktualnyWezel.wartosc;
        }

        public int Nastepnik(Wezel3 w)
        {
            if (w == null)
            {
                throw new ArgumentNullException(nameof(w), "Podany w�ze� nie mo�e by� null.");
            }

            // Je�li w�ze� ma prawe dziecko, to nast�pnikiem b�dzie najmniejsza warto�� w tym poddrzewie.
            if (w.praweDziecko != null)
            {
                return ZnajdzMin(w.praweDziecko);
            }

            // Je�li w�ze� nie ma prawego dziecka, to nast�pnikiem b�dzie pierwszy przodek,
            // kt�rego lewe dziecko jest r�wnie� przodkiem w�z�a w.
            Wezel3 przodek = w.rodzic;
            while (przodek != null && w == przodek.praweDziecko)
            {
                w = przodek;
                przodek = przodek.rodzic;
            }

            // Je�li nie istnieje taki przodek, to w�ze� nie ma nast�pnika.
            if (przodek == null)
            {
                throw new InvalidOperationException("W�ze� nie ma nast�pnika.");
            }

            return przodek.wartosc;
        }

        public int Poprzednik(Wezel3 w)
        {
            if (w == null)
            {
                throw new ArgumentNullException(nameof(w), "Podany w�ze� nie mo�e by� null.");
            }

            // Je�li w�ze� ma lewe dziecko, to poprzednikiem b�dzie najwi�ksza warto�� w tym poddrzewie.
            if (w.leweDziecko != null)
            {
                return ZnajdzMax(w.leweDziecko);
            }

            // Je�li w�ze� nie ma lewego dziecka, to poprzednikiem b�dzie pierwszy przodek,
            // kt�rego prawe dziecko jest r�wnie� przodkiem w�z�a w.
            Wezel3 przodek = w.rodzic;
            while (przodek != null && w == przodek.leweDziecko)
            {
                w = przodek;
                przodek = przodek.rodzic;
            }

            // Je�li nie istnieje taki przodek, to w�ze� nie ma poprzednika.
            if (przodek == null)
            {
                throw new InvalidOperationException("W�ze� nie ma poprzednika.");
            }

            return przodek.wartosc;
         }
    }
}